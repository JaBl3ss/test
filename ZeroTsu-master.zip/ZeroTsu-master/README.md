## ZeroTsu is a Discord BOT with anime and reddit functionalities
<p align="center">
	<img src="https://images-wixmp-ed30a86b8c4ca887773594c2.wixmp.com/f/6e4868e2-f52b-4c7d-a984-d5027576b221/dch684c-818cbf96-b76b-4e75-8445-75d1497195b7.png?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1cm46YXBwOjdlMGQxODg5ODIyNjQzNzNhNWYwZDQxNWVhMGQyNmUwIiwiaXNzIjoidXJuOmFwcDo3ZTBkMTg4OTgyMjY0MzczYTVmMGQ0MTVlYTBkMjZlMCIsIm9iaiI6W1t7InBhdGgiOiJcL2ZcLzZlNDg2OGUyLWY1MmItNGM3ZC1hOTg0LWQ1MDI3NTc2YjIyMVwvZGNoNjg0Yy04MThjYmY5Ni1iNzZiLTRlNzUtODQ0NS03NWQxNDk3MTk1YjcucG5nIn1dXSwiYXVkIjpbInVybjpzZXJ2aWNlOmZpbGUuZG93bmxvYWQiXX0.w_Pmn6zmDv4NcB9h-lPko3-7qnvGmLqVD7862q59XR8" alt="zero two" width="300" height="300">
</p

<br/>

* New Anime Episodes feed SUBBED (DM notifications optional). Source: AnimeSchedule.net

* Daily Anime Schedule. Source: AnimeSchedule.net

* Customizable Reddit RSS Feed autopost system that will post a specific reddit thread based on its settings. Can be set for a specific author, subreddit, post type (rising, hot, new) and title. Can auto pin/unpin that message

* Give or take roles using reactions.

* Automatically give roles to a user when they join a voice channel, and remove them when they leave it. Fully customizable with multiple roles per voice channel and vice versa

* BOT say/edit commands that any mod can use to send or edit important messages with the BOT (e.g. so the entire mod team can edit a message), or pretend they're a ROBOT

* RemindMe feature where it either messages you or pings you with a message you've set after a period of time you've told it

* Raffles with which you can do giveaways. It selects a random user that has joined the raffle (either through command or react) as the winner!

<br/>

Official Discord Support Server: https://discord.gg/BDT8Twv
