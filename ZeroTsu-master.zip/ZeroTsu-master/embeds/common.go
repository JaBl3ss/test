package embeds

var (
	purpleColor    = 6442162
	lightPinkColor = 16758465
)
